<?php

// Here echo command is used to print
echo "Hello, world!";

?>