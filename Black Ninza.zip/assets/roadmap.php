<?php 
// You can use PHP to set the image source dynamically if needed 
$imagePath = '../assets/roadmap.jpg'; // Update this path to your image 
?> 
 
<!DOCTYPE html> 
<html lang="en"> 
<head> 
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>The Official Roadmap Of Balck Ninza</title> 
</head> 
<body> 
 
<h1>The Official Roadmap Of Balck Ninza 2024</h1> 
<img src="<?php echo $imagePath; ?>" alt="This is official roadmap image of Black Ninza" /> 
 
</body> 
</html> 